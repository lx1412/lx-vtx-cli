var path = require('path');
// var webpack = require('webpack');
const ExtractTextPlugin = require("extract-text-webpack-plugin");
const common = require('./webpack/common');
const env = process.env;

module.exports = () => {
  let plugins = common.plugins;
  const extra = require(`./webpack/${env.NODE_ENV}`);
  plugins = plugins.concat(extra.plugins);

  return {
    mode: env.NODE_ENV,
    devServer: {
      contentBase: './public',
      host: '0.0.0.0',
      useLocalIp: true,
      // port: 9000,
      proxy: {
        "/question": {
          "target": "http://192.168.19.239:8088",
          "changeOrigin": true
        }
      }
    },
    devtool: env.NODE_ENV === 'development' ? 'eval-source-map' : false,
    entry: [
      './src/index.js'
    ],
    output: {
      path: path.join(__dirname, 'dist'),
      filename: 'bundle.js',
      publicPath: ''
    },
    plugins,
    resolve: {
      extensions: ['.js', '.jsx']
    },
    module: {
      rules: [
        {
          test: /\.(css|less)$/,
          exclude: /src/,
          use: ExtractTextPlugin.extract({
            fallback: "style-loader",
            use: ["css-loader"]
          })
        }, {
          test: /\.(css|less)$/,
          include: /src/,
          use: ExtractTextPlugin.extract({
            fallback: "style-loader",
            use: ["css-loader?modules&localIdentName=[local]-[hash:base64:5]", "less-loader"]
          })
        }, {
          test: /\.jsx?$/,
          use: ['babel-loader'],
          include: path.join(__dirname, 'src')
        }]
    }
  }
};
