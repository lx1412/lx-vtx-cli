import React from 'react';
import { Router, Route, Switch, Redirect} from 'react-router';
import dynamic from 'dva/dynamic';

function RouterConfig({ history, app }) {

  const pageList = [
    {
      path:"/index",
      models:() => [
        import('./models/index'),
      ],
      component:() => import('./routes/index'),
    },
  ];
  return (
    <Router history={history}>
      <Switch>
        {
          pageList.map(({path,exact, ...rest},index) => {
            return <Route
              path={path}
              component={dynamic({
                app,
                ...rest
              })}
              key={index}
            />
          })
        }
      </Switch>
    </Router>
  );
}

export default RouterConfig;
