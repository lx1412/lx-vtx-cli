//import 'babel-polyfill';
import dva from 'dva';
// import './index.less';

// import 'moment/locale/zh-cn';
// moment.locale('zh-cn');


// 1. Initialize
export const app = dva();

// 2. Plugins
// app.use({});

// 3. Model

// GIS
/*app.model(require('./models/GIS/monitor'));*/


// 4. Router
app.router(require('./router'));

// 5. Start
app.start('#root');
