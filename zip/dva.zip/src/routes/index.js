import React from 'react';

import { connect } from 'dva';

import styles from './style.less';

function C (props){
    return <div className={styles.example}>{props.state.hello}</div>
}

const mapStateToProps = (state) => {
    return {
        state: state.index
    }
};

const mapDispatchToProps = (dispatch) => ({ dispatch });

export default connect(mapStateToProps, mapDispatchToProps)(C);
