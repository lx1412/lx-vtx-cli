import _ from 'lodash';
import moment from 'moment';

//序列化数据
export function jsonToUrl(jsonData) {
  let html = "";
  for (let i in jsonData) {
    html += `&${i}=${jsonData[i]}`
  }
  return html.slice(1);
}

export function getParameterByName(name, url) {
  if (!url) url = window.location.href;
  name = name.replace(/[\[\]]/g, "\\$&");
  var regex = new RegExp("[?&]" + name + "(=([^&#]*)|&|#|$)"),
    results = regex.exec(url);
  if (!results) return '';
  if (!results[2]) return '';
  return decodeURIComponent(results[2].replace(/\+/g, " "));
}

export function getQueryStringFromObj(obj) {
	return _.toPairs({..._.omitBy(obj, (val)=>(val == null)), randomKey: moment().valueOf()})
	.map(val => `${encodeURIComponent(val[0])}=${encodeURIComponent(val[1])}`)
	.join('&');
}

//获取地址
export const getAddress = (lnglat) => {
  return new Promise((resolve) => {
    new BMap.Geocoder().getLocation(new BMap.Point(lnglat[0],lnglat[1]), (rs) => {
      resolve(rs.address);
    });
  });
};

//延迟
export const delay = (time) => {
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      resolve();
    }, time)
  })
};

export class mapPointsProcessor {
  constructor(gridSpacing) {
      this.GRIDSPACING = gridSpacing || 40;
      this.mapHeight = null; //地图高度
      this.mapWidth = null; //地图宽度
      // 若地图大小不变，zoom不变，网格的经纬度间隔应该保持不变以保证前后两次网格位置保持一致
      this.lngInterval = null; //划分的网格经度间隔
      this.latInterval = null; //划分的网格纬度间隔
      this.maxLat = null,
          this.minLat = null,
          this.maxLng = null,
          this.minLng = null
  }
  resetMapConfig(param) {
      // 若没传地图相关参数默认使用上次的地图参数
      const { mapHeight, mapWidth, maxLat, minLat, maxLng, minLng, eType } = param;
      this.maxLat = maxLat || this.maxLat;
      this.minLat = minLat || this.minLat;
      this.maxLng = maxLng || this.maxLng;
      this.minLng = minLng || this.minLng;
      // 当操作为zoom（改变最大最小经纬度）或地图宽高改变则重新计算网格
      if (eType == 'zoom' || (mapHeight && mapHeight != this.mapHeight) || (mapWidth && mapWidth != this.mapWidth)) {
          this.mapHeight = mapHeight || this.mapHeight;
          this.mapWidth = mapWidth || this.mapWidth;
          this.calGridInterval();
      }
  }
  calGridInterval() {
      const x_num = Math.ceil(this.mapWidth / this.GRIDSPACING);
      const y_num = Math.ceil(this.mapHeight / this.GRIDSPACING);
      this.lngInterval = parseFloat(((this.maxLng - this.minLng) / x_num).toFixed(6));
      this.latInterval = parseFloat(((this.maxLat - this.minLat) / y_num).toFixed(6));
  }
  pointFilter(param) {
      // allPoints为必填参数
      const { allPoints, reservedPoints = [] } = param;
      //let areaopt = getAreaOpt(allPoints);
      this.resetMapConfig(param);

      let hashPoints = {};
      for (let i = 0, len = allPoints.length; i < len; i++) {
          let p_lng = allPoints[i].longitude;
          let p_lat = allPoints[i].latitude;
          if (p_lng > this.maxLng || p_lng < this.minLng || p_lat > this.maxLat || p_lat < this.minLat) {
              continue;
          }
          let x_index = parseInt(p_lng / this.lngInterval);
          let y_index = parseInt(p_lat / this.latInterval);
          let hashIndex = x_index + '-' + y_index;
          if (!hashPoints[hashIndex]) {
              hashPoints[hashIndex] = allPoints[i];
          }
      }

      let filteredPoints = [...reservedPoints];
      let reservedIds = reservedPoints.map((item) => item.id

      );
      for (let k in hashPoints) {
          let the_point = hashPoints[k];
          if (reservedIds.indexOf(the_point.id

          ) == -1) {
              filteredPoints.push(the_point);
          }
      }

      return filteredPoints;
  }
}

//格式化时间
export const formatTime = (time) => {
  let h = Math.floor(time / (60 * 60 * 1000)),
    m = Math.floor((time/60000) % 60),
    s = Math.floor((time/1000) % 60),
    tc = [];

  if (h > 0) {
    tc.push(h);
  }

  tc.push((m < 10 && h > 0 ? "0" + m : m));
  tc.push((s < 10  ? "0" + s : s));

  return h > 0 ? h + "小时" : "" + m > 0 ?  m + "分钟" : "";

};
sessionStorage.setItem('tenantId', getParameterByName('tenantId') || "d9552d18009049059cbc5521fa3427e1");
sessionStorage.setItem('userId', getParameterByName('userId') || "38c043c860294915bb75a7bc1bb8e95e");
window.token = getParameterByName('token');
export const scheduleHost = "http://192.168.1.217:18107";  //测试排班服务地址
//export const scheduleHost = "http://120.27.248.90:18107";  //生产排班服务地址



