import request from '../utils/request';

//序列化数据
import { jsonToUrl } from '../utils/config';

//json格式headers
let jsonHeaders = new Headers();
jsonHeaders.append("Content-Type", "application/json");

//键值对格式的headers
let wHeaders = new Headers();
wHeaders.append("Content-Type", "application/x-www-form-urlencoded");

export function fetchCommonParams(params) {
  // let parameters = JSON.stringify(params);
  return request(`/cloud/management/rest/np/param/getByParamTypeCode?parameters={"paramTypeCode":"param_report_constant","tenantId":"${sessionStorage.getItem("tenantId")}"}`, {
    method: 'get',
    'content-type': wHeaders
  })
    .then(({ data }) => data || [])
    .catch(() => []);;
}

export function getCarTree(params) {
  return request(`/cloud/zyqs/api/v101/common/loadDeptCarTree?`+jsonToUrl(params), {
    method: 'get',
    'content-type': wHeaders
  })
    .then(({ data }) => data ? [data] : [])
    .catch(() => []);
}

export function getTypeCode(params) {
  let parameters = JSON.stringify(params);
  return request(`/cloud/management/rest/np/param/getByParamTypeCode?parameters=${parameters}`, {
    method: 'get',
    'content-type': wHeaders
  })
    .then(({ data }) => data || [])
    .catch(() => []);
}

export function fetchUnit(params) {
  let parameters = JSON.stringify(params);
  return request(`/cloud/management/rest/np/tenant/dept/loadOrgTreeByPermission?parameters=${parameters}`, {
    method: 'get',
    'content-type': wHeaders
  })
    .then(({ data }) => JSON.parse(data).items || [])
    .catch(() => []);
}

export function getRoadTree(params) {
  return request(`/cloud/zyqs/api/v101/common/loadDeptRoadTree?`+jsonToUrl(params), {
    method: 'get',
    'content-type': wHeaders
  })
    .then(({ data }) => data ? [data] : [])
    .catch(() => []);
}

export const history={
  getDispatchList:function(params){
    return request(`/cloud/zyqs/api/v101/dispatchTask/list?${jsonToUrl(params)}`, {
      method: 'get',
    })
  },
  getDetailList:function(id){
    return request(`/cloud/zyqs/api/v101/dispatchTask/getDispatchTaskReceiversDto?id=${id}`, {
      method: 'get',
    }).then(({ data }) => data || [])
      .catch(() => ([]));
  },
  getTrackList:function(id){
    return request(`/cloud/zyqs/api/v101/dispatchTask/track?id=${id}`, {
      method: 'get',
    }).then(({ data }) => data || [])
      .catch(() => ([]));
  },
};

export function getTenantOpt(tenantId) {
  let params={
    id:tenantId
  };
  let parameters=encodeURIComponent(JSON.stringify(params));
  return request(`/cloud/management/rest/np/tenant/getTenantById?parameters=${parameters}`, {
    method: 'get',
  })
}

export function getCarTypeList() {
  return request(`/cloud/zyqs/api/v101/common/listCarType`, {
    method: 'get',
    'content-type': wHeaders
  })
    .then(({ data }) => data || [])
    .catch(() => []);
}
