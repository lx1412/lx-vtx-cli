const env = process.env;

const path = require('path');
const webpack = require('webpack');
const ExtractTextPlugin = require("extract-text-webpack-plugin");

const common = require('./webpack/common');
const extra = require(`./webpack/${env.NODE_ENV}`);

module.exports = () => {
    let plugins = common.plugins;
    plugins = plugins.concat(extra.plugins);
    return {
        mode: env.NODE_ENV,
        entry: './src/index.js',
        devtool: env.NODE_ENV === 'development' ? 'eval-source-map' : false,
        devServer: {
            contentBase: './public',
            host: '0.0.0.0',
            useLocalIp: true,
            proxy: {
                "/cloud/web/videoMonitor/": {
                    "target": "http://116.62.100.64:18096"
                }
            }
        },
        plugins,
        module: {
            rules: [{
                test: /\.(css|less)$/,
                exclude: /src/,
                use: ExtractTextPlugin.extract({
                    fallback: "style-loader",
                    use: ["css-loader"]
                })
            }, {
                test: /\.(css|less)$/,
                include: /src/,
                use: ExtractTextPlugin.extract({
                    fallback: "style-loader",
                    use: ["css-loader?modules&localIdentName=[local]-[hash:base64:5]", "less-loader"]
                })
            }, {
                test: /\.(js|jsx)$/,
                exclude: /node_modules/,
                use: ['babel-loader']
            },
            {
                test: /\.(png|svg|jpg|gif)$/,
                use: ['file-loader']
            },
            {
                test: /\.(woff|eot|ttf)$/,
                use: ['file-loader']
            }
            ]
        },
        output: {
            filename: 'index.js',
            path: path.resolve(__dirname, 'dist'),
            publicPath: ""
        },
    };
}
