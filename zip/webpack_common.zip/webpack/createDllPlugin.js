const path = require('path');
const fs = require('fs');
const { promisify } = require('util');
const webpack = require('webpack');
const colors = require('colors/safe');

const vendorKeys = require('./vendorKeys');

const env = process.env;
const webpackP = promisify(webpack);

module.exports = class {
    apply(compiler) {
        let hookName = env.NODE_ENV === 'development' ? 'watchRun' : 'beforeRun';

        const createRefPlugin = (k) => new webpack.DllReferencePlugin({
            manifest: require(path.join(__dirname, `../public/resources/dll/${k}-manifest.json`)),
        }).apply(compiler);

        let cb = () => {
            Object.keys(vendorKeys()).forEach(createRefPlugin)
        }

        let created = this._createDll().then(cb);

        compiler.hooks[hookName].tapPromise('p', c => created);
    }

    _createDll() {
        process.stdout.write(colors.yellow.underline("正在创建DLL……\r\n"));

        return webpackP(require('./dll')(env))
            .then(stats => {
                let err = stats.hasErrors();
                if (err) {
                    throw err;
                }

                process.stdout.write(colors.green.bold("创建DLL成功\r\n"));

                let json = require('../package.json');

                json.lastDependencies = json.dependencies;

                fs.writeFileSync(path.join(__dirname, '../package.json'), JSON.stringify(json, null, 4));
            })
            .catch(e => {
                console.dir(e)
                process.stdout.write(colors.red.bold("创建DLL失败\r\n"));
                process.exit(1);
            });
    }
}

