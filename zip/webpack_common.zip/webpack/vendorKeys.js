const fs=require('fs');
const path=require('path');
const { zipObject, chunk, } = require('lodash');

module.exports=()=>{
    let str=fs.readFileSync(path.join(__dirname,'../','package.json'));
    let json=JSON.parse(str);

    let vendorKeys = Object.keys(json.dependencies);

    return zipObject(vendorKeys.map(k=>k.replace(/-/g,'_')),chunk(vendorKeys));
}
