const path = require('path');
const webpack = require('webpack');
const UglifyJsPlugin = require('uglifyjs-webpack-plugin');
// const TerserPlugin = require('terser-webpack-plugin');
const fs = require('fs-extra');

const vendorKeys = require('./vendorKeys');

module.exports = env => {
    const isDev = env.NODE_ENV === 'development';
    console.log('mode', env.NODE_ENV)
    const dirPath = path.join(__dirname, '../public/resources/dll');

    try {
        fs.emptyDirSync(dirPath);
    }
    catch (e) { console.dir(e) }

    return {
        mode: env.NODE_ENV,
        entry: vendorKeys(),
        cache:true,
        devtool: false,
        output: {
            path: dirPath,
            filename: '[name].dll.[chunkhash].js',
            library: '[name]_library'
        },
        plugins: [
            new webpack.DllPlugin({
                path: path.join(__dirname, '../public/resources/dll', '[name]-manifest.json'),
                name: '[name]_library'
            })
        ],
        optimization: {
            minimize: !isDev,
            minimizer: [
                new UglifyJsPlugin({
                    cache: path.join(__dirname, '../', `node_modules/.cache/${env.NODE_ENV}-dll-uglifyjs-webpack-plugin`),
                    // parallel: true,
                    uglifyOptions: {
                        warnings: isDev,
                        compress: {
                            drop_console: !isDev,
                            // dead_code: !isDev,
                        }
                    }
                })
            ],
        }
    }
};
