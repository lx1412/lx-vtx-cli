const ExtractTextPlugin = require("extract-text-webpack-plugin");
const HtmlWebpackPlugin = require('html-webpack-plugin');
const path = require('path');
const webpack = require('webpack');
const HtmlWebpackIncludeAssetsPlugin=require('lx-html-webpack4-include-assets-plugin');

const CreateDllPlugin = require('./createDllPlugin');

module.exports = {
    plugins: [
        new CreateDllPlugin(),
        new webpack.DefinePlugin({
            'process.env': { NODE_ENV: `'${process.env.NODE_ENV}'` }
        }),
        new ExtractTextPlugin("index.[hash].css"),
        new HtmlWebpackPlugin({
            template: path.join(__dirname, '../src', 'index.html'),
            inject: true,
            // hash:true,
        }),
        new HtmlWebpackIncludeAssetsPlugin({
            assets: [{ path: '/resources/dll/', glob: '*.js', globPath: 'public/resources/dll' }],
            append: false
        })
    ],
};
