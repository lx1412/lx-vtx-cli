import text from './text';

export default {
    text
}
