export default {
    namespaced: true,
    state: {
        html: '111',
    },
    mutations: {
        updateState(state, {payload}) {
            state = Object.assign(state, payload);
        },
        updateByKey(state, key, payload) {
            state[key] = { ...state[key], ...payload };
        }
    }
}
