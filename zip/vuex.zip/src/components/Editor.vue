<template>
    <quill-editor ref="myQuillEditor" v-model="html"></quill-editor>
</template>

<script>
import { quillEditor } from "vue-quill-editor";
import { mapState } from "vuex";

// require styles
import 'quill/dist/quill.core.css'
import 'quill/dist/quill.snow.css'
import 'quill/dist/quill.bubble.css'

export default {
  components: {
    quillEditor
  },
  data() {
    return {};
  },
  computed: {
    html: {
      get() {
        return this.$store.state.text.html;
      },
      set(html) {
        this.$store.commit({ type: "text/updateState", payload: { html } });
      }
    },
    // editor() {
    //   return this.$refs.myQuillEditor.quill;
    // }
  },
  mounted() {
    // console.log("this is current quill instance object", this.editor);
  }
};
</script>

