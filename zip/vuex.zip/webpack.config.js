const path = require('path');
const ExtractTextPlugin = require("extract-text-webpack-plugin");

const common = require('./webpack/common');
const env = process.env;


module.exports = () => {
    let plugins = common.plugins;

    const extra = require(`./webpack/${env.NODE_ENV}`);

    plugins = plugins.concat(extra.plugins);

    return {
        mode: env.NODE_ENV,
        entry: './src/main.js',
        devtool: env.NODE_ENV === 'development' ? 'eval-source-map' : false,
        resolve: {
            extensions: ['.js', '.vue'],
        },
        devServer: {
            contentBase: './public',
            host: '0.0.0.0',
            useLocalIp: true,
            port: 9000,
            publicPath: "/",
            proxy: {
                "/cloud/web/videoMonitor/": {
                    "target": "http://116.62.100.64:18096"
                },
                "/cloud/zyqs/api/v101/": {
                    "target": "http://192.168.1.218:18208",
                    "changeOrigin": true
                },
                "/cloud/management/": {
                    "target": "http://222.92.212.126:18089",
                    "changeOrigin": true
                },
                "/cloudFile/common/": {
                    "target": "http://222.92.212.126:18084",
                    "changeOrigin": true
                }
            }
        },
        plugins,
        module: {
            rules: [{
                test: /\.(css|less)$/,
                exclude: /src/,
                use: ExtractTextPlugin.extract({
                    fallback: "style-loader",
                    use: ["css-loader"]
                })
            }, {
                test: /\.(css|less)$/,
                include: /src/,
                use: ExtractTextPlugin.extract({
                    fallback: "style-loader",
                    use: ["css-loader?modules&localIdentName=[local]-[hash:base64:5]", "less-loader"]
                })
            }, {
                test: /\.vue$/,
                loader: 'vue-loader',
                options: {
                    extractCSS: true,
                    // loaders:{
                    //     cssModules: {
                    //         localIdentName: '[path][name]---[local]---[hash:base64:5]',
                    //         camelCase: true
                    //       }
                    // }
                }
            }, {
                test: /\.js$/,
                exclude: /node_modules/,
                use: [{
                    loader: 'babel-loader',
                    options: {
                        "presets": ["es2015", "stage-2"],
                        "plugins": [
                            [
                                "add-module-exports",
                                "transform-runtime",
                                "syntax-dynamic-import",
                                {
                                    "polyfill": false,
                                    "regenerator": true
                                }
                            ]
                        ]
                    }
                }]
            },
            {
                test: /\.(png|svg|jpg|gif)$/,
                use: ['file-loader']
            },
            {
                test: /\.(woff|eot|ttf)$/,
                use: ['file-loader']
            },
            {
                test: /\.html$/,
                use: ['html-loader']
            }
            ]
        },
        output: {
            filename: 'index.[hash].js',
            path: path.resolve(__dirname, 'dist'),
            publicPath: ""
        },
    };
}

